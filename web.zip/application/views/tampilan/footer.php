<footer class="footer">
            <div class="container">
                <div class="row">
                    <div class="col-md-2">
                        <p class="copyright pull-left"> 2015 Ruangsalon.com</p>
                    </div>
                    <div class="col-md-5">
                        <ul style="list-style: none; display: -webkit-box;">
                            <li><a href="#about" target="_self">Tentang Kami</a></li>
                            <li class="ml-10"><a href="#kontak" target="_self">Kontak</a></li>
                            <li class="ml-10"><a href="#contumer-services" target="_self">Help Center</a></li>
                            <li class="ml-10"><a href="#peraturan" target="_self">Privacy Policy</a></li>
                            <li class="ml-10"><a href="#termsNcondition" target="_self">Terms &amp; conditions</a></li>
                        </ul>
                    </div>
                    <div class="col-md-4">
                        <ul class="right" style="list-style: none; display: -webkit-box; padding-left: 30px;">
                            <li><i class="fa fa-facebook-square fa-2x"></i></li>
                            <li><i class="fa fa-instagram fa-2x"></i></li>
                            <li><i class="fa fa-twitter-square fa-2x"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </footer>
       
    </body>
</html>